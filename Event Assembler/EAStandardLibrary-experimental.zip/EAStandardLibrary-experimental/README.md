# EA Standard Library

_**Note**: this is an **unofficial** (and probably temporary) repository that's here to provide a way for the community to contribute while Colorz decides on how to handle an official one._

This is the standard library for Event Assembler meant to be used when working with FE6J, FE7J, FE7U or FE8U.

This is typically distributed with the full Event Assembler package, alongside Core(s), the Event Assembler GUI and the standard Tools.

This repository is specifically composed of:

- The standard `Language Raws`.
- `EAstdlib.event` and its dependencies (the content of the `EA Standard Library` folder).
- Standard `Extensions`.
